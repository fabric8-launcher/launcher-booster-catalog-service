http://appdev-stage.openshift.io/docs/spring-boot-runtime.html#mission-crud-spring-boot-tomcat
