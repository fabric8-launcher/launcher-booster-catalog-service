http://appdev.openshift.io/docs/vertx-runtime.html#mission-configmap-vertx
