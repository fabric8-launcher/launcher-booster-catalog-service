http://appdev.openshift.io/docs/vertx-runtime.html#mission-crud-vertx
