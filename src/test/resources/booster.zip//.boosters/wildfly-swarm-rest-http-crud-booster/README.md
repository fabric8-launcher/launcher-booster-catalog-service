http://appdev-stage.openshift.io/docs/wf-swarm-runtime.html#mission-crud-wf-swarm
