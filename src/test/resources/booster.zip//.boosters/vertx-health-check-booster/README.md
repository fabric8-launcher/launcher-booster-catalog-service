http://appdev.openshift.io/docs/vertx-runtime.html#mission-health-check-vertx
