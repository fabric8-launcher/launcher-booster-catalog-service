http://appdev-stage.openshift.io/docs/wf-swarm-runtime.html#mission-configmap-wf-swarm
