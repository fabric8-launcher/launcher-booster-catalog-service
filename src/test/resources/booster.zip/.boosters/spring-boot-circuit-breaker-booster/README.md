http://appdev-stage.openshift.io/docs/spring-boot-runtime.html#mission-circuit-breaker-spring-boot
