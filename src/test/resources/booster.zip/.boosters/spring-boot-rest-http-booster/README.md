http://appdev-stage.openshift.io/docs/spring-boot-runtime.html#mission-http-api-spring-boot-tomcat
