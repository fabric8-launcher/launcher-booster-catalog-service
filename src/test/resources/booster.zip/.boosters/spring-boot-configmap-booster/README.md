http://appdev-stage.openshift.io/docs/spring-boot-runtime.html#mission-configmap-spring-boot-tomcat
