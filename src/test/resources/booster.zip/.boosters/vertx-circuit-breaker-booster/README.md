http://appdev.openshift.io/docs/vertx-runtime.html#mission-circuit-breaker-vertx
