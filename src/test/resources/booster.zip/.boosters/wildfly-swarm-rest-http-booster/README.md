http://appdev-stage.openshift.io/docs/wf-swarm-runtime.html#mission-http-api-wf-swarm
